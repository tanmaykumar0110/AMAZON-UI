export const products=[
{id:1,title:"Wireless Headphones",price:2999,rating:4.5,image:"https://m.media-amazon.com/images/I/61CGHv6kmWL._SL1500_.jpg",description:"High quality wireless headphones"},
{id:2,title:"Smart Watch",price:1999,rating:4.2,image:"https://m.media-amazon.com/images/I/61ZjlBOp+rL._SL1500_.jpg",description:"Fitness smart watch"}
]