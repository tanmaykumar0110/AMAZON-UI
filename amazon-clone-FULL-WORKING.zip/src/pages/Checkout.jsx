export default function Checkout(){
return(<div style={{padding:"20px"}}>
<h2>Checkout</h2>
<input placeholder="Name"/>
<input placeholder="Address"/>
<input placeholder="City"/>
<input placeholder="Pincode"/>
<button>Place Order</button>
</div>)}